import React, { useEffect, useState } from "react";
import "./App.css";
import Navbar from "./components/Navbar";
import Question from "./components/Question";
import axios from "axios";

function countdownTimer(setTimeRemaining) {
  let examDuration = 1; // Exam duration in minutes
  let now = new Date().getTime(); // Current time in milliseconds
  let examEnd = now + examDuration * 60000; // Exam end time in milliseconds

  // Update the timer every second
  let timerInterval = setInterval(function () {
    now = new Date().getTime(); // Current time in milliseconds

    let timeRemaining = Math.floor((examEnd - now) / 1000); // Remaining time in seconds



    // Check if the timer has reached zero
    if (timeRemaining <= 0) {
      clearInterval(timerInterval);
      setTimeRemaining(0);
      return;
    }

    setTimeRemaining(timeRemaining);
  }, 1000); // Update every second
}

function App() {
  const [timeRemaining, setTimeRemaining] = useState(100000);
  const [data, setData] = useState({});

  useEffect(() => {
    countdownTimer(setTimeRemaining);
  }, []);

  useEffect(() => {
    axios
      .get("http://localhost/login_system/user_data.php", {
        withCredentials: true,
      })
      .then((response) => {
        setData(response.data);
        // console.log(response.data);
      })
      .catch((error) => {
        console.error(`Error fetching data: ${error}`);
      });
  }, []);

  useEffect(() => {
  }, [timeRemaining]);

  return (
    <div className="App">
      <Navbar data={data} timeRemaining={timeRemaining}/>
      <Question data={data} timeRemaining={timeRemaining}/>
    </div>
  );
}

export default App;
