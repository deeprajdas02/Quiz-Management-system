<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = 'localhost';
$hostdb   = 'hostdb';
$user = 'root';
$pass = '';
$connection = new mysqli($host, $user, $pass , $hostdb);
$query = "SELECT dbname FROM table1";
$result = $connection->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_array();
    $columnValue = $row[0];  // Access the column value using the index
    $db = $columnValue;
} else {
    // echo "No rows found.";
}
$result->close();
$connection->close();
$host = 'localhost';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$opt = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $opt);

$stmt = $pdo->query('SELECT * FROM questions ORDER BY RAND() LIMIT 20');
$questions = $stmt->fetchAll();


// $userdb = 'response';
// $conn = new mysqli($host, $user, $pass);
// $sql = "CREATE DATABASE `$userdb`";
// $result1 = mysqli_query($conn, $sql);
// $conn1 = mysqli_connect($host, $user, $pass, $userdb);

// if($result1)
// {
//     $sql = "CREATE TABLE `$userdb`.`responses` (`user_id` VARCHAR(11) NOT NULL, `question_id` INT(11) NOT NULL  , `selected_option` VARCHAR(200) NOT NULL ,`correct_option` VARCHAR(200) NOT NULL  ,  PRIMARY KEY (`question_id`))";           
//     $result2 = mysqli_query($conn1, $sql);
// }
// else
//     echo "The databse was not created successfully because of this error ----><br>". mysqli_error($conn);




echo json_encode($questions);
?>

