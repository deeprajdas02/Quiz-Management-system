// fetch('http://localhost/cra/src/utils/file.php')
//     .then(response => response.json())
//     .then(data => {
//         // data now contains your 50 questions
//         // let's shuffle them and select 20

//         for(let i = data.length - 1; i > 0; i--){
//             const j = Math.floor(Math.random() * i);
//             const temp = data[i];
//             data[i] = data[j];
//             data[j] = temp;
//         }

//         const selectedQuestions = data.slice(0, 10);
//         this.setState({ questions: selectedQuestions }); // assuming you're in a React Component
//     });

// function handleSubmit() {
//     fetch('http://localhost/cra/src/utils/script.php'), {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//             user_id: userId, // This needs to be set somewhere
//             responses: responses, // This needs to be an array of { question_id, selected_option }
//         }),

fetch("http://localhost/cra/src/utils/script.php")
  .then((response) => {
    if (!response.ok) {
      throw new Error("HTTP error " + response.status);
    }
    return response.json();
  })
  .then((json) => {
    console.log(json);
    // Here you can do whatever you want with the questions
    // They are in the 'json' variable
  })
  .catch(function () {
    console.log("An error occurred while fetching the questions.");
  });

// export const questionArray = [
//   {
//     question: "What is the capital of India?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Delhi", "Mumbai", "Kolkata", "Chennai"],
//   },
//   {
//     question: "What is the capital of Australia?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Sydney", "Melbourne", "Canberra", "Perth"],
//   },
//   {
//     question: "What is the capital of USA?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["New York", "Washington DC", "Los Angeles", "Chicago"],
//   },
//   {
//     question: "What is the capital of UK?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["London", "Manchester", "Birmingham", "Liverpool"],
//   },
//   {
//     question: "What is the capital of China?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Shanghai", "Beijing", "Shenzhen", "Guangzhou"],
//   },
//   {
//     question: "What is the capital of Japan?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Tokyo", "Osaka", "Kyoto", "Yokohama"],
//   },
//   {
//     question: "What is the capital of France?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Paris", "Marseille", "Lyon", "Toulouse"],
//   },
//   {
//     question: "What is the capital of Germany?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Berlin", "Hamburg", "Munich", "Cologne"],
//   },
//   {
//     question: "What is the capital of Italy?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Rome", "Milan", "Naples", "Turin"],
//   },
//   {
//     question: "What is the capital of Brazil?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Sao Paulo", "Rio de Janeiro", "Brasilia", "Salvador"],
//   },
//   {
//     question: "What is the capital of Canada?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Toronto", "Montreal", "Vancouver", "Ottawa"],
//   },
//   {
//     question: "What is the capital of Russia?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Moscow", "Saint Petersburg", "Novosibirsk", "Yekaterinburg"],
//   },
//   {
//     question:
//       "WWhich one of the following river flows between Vindhyan and Satpura ranges? ",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Narmada", "Mahanadi", "Son", "Netravati"],
//   },
//   {
//     question: "The Central Rice Research Station is situated in?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Chennai", "Cuttack", "Bangalore", "Quilon"],
//   },
//   {
//     question: "Who among the following wrote Sanskrit grammar?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Kalidasa", "Charak", "Panini", "Aryabhatt"],
//   },
//   {
//     question: "Which among the following headstreams meets the Ganges in last?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Alaknanda", "Pindar", "Mandakini", "Bhagirathi"],
//   },
//   {
//     question: "The metal whose salts are sensitive to light is?",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Zinc", "Silver", "Copper", "Aluminum"],
//   },
//   {
//     question: "Patanjali is well known for the compilation of",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Yoga Sutra", "Panchatantra", "Brahma Sutra", " Ayurveda"],
//   },
//   {
//     question:
//       "Which one of the following rivers originates in Brahmagiri range of Western Ghats",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Pennar", "Cauvery", "Krishna", "Tapti"],
//   },
//   {
//     question: "Volcanic eruption do not occur in the",
//     isVisited: false,
//     isAnswered: false,
//     usersResponse: null,
//     options: ["Baltic sea", "Black sea", "Caribbean sea", "Caspian sea"],
//   },
// ];
