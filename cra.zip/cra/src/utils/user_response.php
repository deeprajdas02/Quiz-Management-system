<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header("HTTP/1.1 200 OK");
    die();
}

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['user_id']) && is_array($data['responses'])) {
    $host = 'localhost';
    $db   = 'response';
    $user = 'root';
    $pass = '';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    $pdo = new PDO($dsn, $user, $pass, $opt);
    
    $insertStmt = $pdo->prepare('INSERT INTO responses (user_id, question_id, selected_option, correct_option , db_name) VALUES (?,?,?,?,?)');

    foreach ($data['responses'] as $response) {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM responses WHERE user_id = ? AND question_id = ? AND db_name = ?');
        $stmt->execute([$data['user_id'], $response['question_id'], $response['db_name']]);
        $count = $stmt->fetchColumn();

        if ($count == 0) {
            $selectedOption = $response['selected_option'] ?? null;
            $insertStmt->execute([$data['user_id'], $response['question_id'], $selectedOption, $response['correctAnswer'] , $response['db_name'] ]);
        } else {
            error_log("User ID {$data['user_id']} has already answered question {$response['question_id']}.");
            http_response_code(409);
            echo json_encode(['status' => 'error', 'message' => "User ID {$data['user_id']} has already answered question {$response['question_id']}."]);
            die();
        }
    }
    echo json_encode(['status' => 'success', 'message' => 'Responses saved successfully']);
} else {
    error_log("Invalid or missing user ID or responses.");
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid or missing user ID or responses']);
}
?>
