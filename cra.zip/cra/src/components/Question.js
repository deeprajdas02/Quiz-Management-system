import { React, useRef, useState, useEffect } from "react";
import Navbar from "./Navbar";
import axios from "axios";
// import { questionArray as questionsArray } from "../utils/questionsDataset";

function Question(props) {
  const {data,timeRemaining} = props;
  const questionButtonClass =
    "lg:m-1 sm:m-1 xs:m-1 lg: xs:h-[4vh] xs:w-[4vw] sm:h-[5vh] lg:h-[5vh] w-[4vw] border-solid border-2 border-black rounded-lg flex justify-center items-center font-bold lg:text-l sm:text-xl xs:text-l bg-gray-400 cursor-pointer xs:p-1 ";

  const [activeQuestion, setActiveQuestion] = useState(0);
  const [questionArray, setQuestionArray] = useState([]);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [responses, setResponses] = useState([]);
  const [selectedOption, setSelectedOption] = useState(null);

  useEffect(()=>{
    if(timeRemaining<=0){
      submitResponses();
      alert("Time is up!! EXAM OVER !!");
    }
    console.log(timeRemaining);
  },[timeRemaining]);

  useEffect(() => {
    // Fetch questions from API
    axios.get("http://localhost/cra/src/utils/script.php")
      .then((response) => {
        // Check if response data is an array
        if (Array.isArray(response.data)) {
          // Transforming response to match the format used in your code
          const formattedData = response.data.map((question, index) => ({
            id: question.sno,
            question: question.question,
            options: [
              question.option_a,
              question.option_b,
              question.option_c,
              question.option_d,
            ],
            correctAnswer: question.correct_option,
            isVisited: index === 0, // Make the first question visited here
            usersResponse: null,
            dbname:question.dbname,
          }));
          setQuestionArray(formattedData);
        } else {
          console.error("Response data is not an array:", response.data);
        }
      })
      .catch((error) => {
        console.error("Error fetching questions:", error);
      });
  }, []);
  

  const makeVisited = (indexOfButton) => {
    const updatedQuestionsArray = [...questionArray];
    updatedQuestionsArray[indexOfButton].isVisited = true;
    setQuestionArray(updatedQuestionsArray);
  };

  const buttons = Array.from({ length: 20 }, (_, i) => i + 1);

  const renderButton = (buttonNumber) => {
    const questionIndex = buttonNumber - 1;
  
    if (
      !questionArray ||
      questionIndex < 0 ||
      questionIndex >= questionArray.length
    ) {
      // Handle the case where questionArray is undefined or the index is out of bounds
      return null;
    }
  
    const question = questionArray[questionIndex];
    const isVisited = question && question.isVisited;
    const isAnswered = question && question.usersResponse;
    let buttonStyle = questionButtonClass;
  
    if (isAnswered !== null) {
      buttonStyle += " bg-green-400";
    } else if (isVisited) {
      buttonStyle += " bg-yellow-400";
    } else {
      buttonStyle += " bg-gray-400";
    }
  
    return (
      <div
        className={buttonStyle}
        onClick={() => {
          setSelectedAnswer(null);
          makeVisited(questionIndex);
          setActiveQuestion(questionIndex);
        }}
      >
        {buttonNumber}
      </div>
    );
  };
  
  const renderRow = (start) => {
    return (
      <div className="flex m-4 justify-center">
        {buttons.slice(start, start + 5).map(renderButton)}
      </div>
    );
  };

  const answerSelected = (buttonNumber) => {
    setSelectedAnswer(buttonNumber);
  };

  const saveAnswer = () => {
    if (selectedAnswer === null) {
      alert("No answer selected");
      return;
    }
    const questionSerialNo = questionArray[activeQuestion].id;
    const questionCorrectOption = questionArray[activeQuestion].correctAnswer;
    const databaseName = questionArray[activeQuestion].dbname;
    const updatedQuestionsArray = [...questionArray];
    updatedQuestionsArray[activeQuestion].usersResponse = selectedAnswer;
    setQuestionArray(updatedQuestionsArray);

    // Accumulate the user's responses
    const updatedResponses = [
      ...responses,
      {
       
        question_id:  questionSerialNo, // I'm assuming that your question IDs start at 0
        selected_option: selectedAnswer,
        user_id: props?.data?.cfid,
        correctAnswer : questionCorrectOption,
        db_name : databaseName
      },
      
    ];
    setResponses(updatedResponses);
    console.log(updatedResponses);
  };

  const submitResponses = () => {
    axios
      .post("http://localhost/cra/src/utils/user_response.php", {
        user_id: props?.data?.cfid, // replace this with the actual user ID
        responses,data,
      })
      .then((response) => {
        if (response.data.status === "success") {
          // Do something on success, maybe show a success message to the user
          console.log(responses);
          alert("Successfully submitted !!");
          window.open('http://localhost/login_system/login_form.php', '');
        } else {
          // Handle error, maybe show an error message to the user
          console.error(response.data.message);
        }
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const clearAnswer = () => {
    setSelectedAnswer(null);
    const updatedQuestionsArray = [...questionArray];
    updatedQuestionsArray[activeQuestion].usersResponse = null;
    setQuestionArray(updatedQuestionsArray);
    // setIsAnswerSaved(false);
  };

  if (questionArray.length === 0) {
    return <div>Loading...</div>;
  }

  return (
    <div className="flex">
      <div className="xs:w-[65vw] lg:w-[84vw]">
        <div className="h-[55vh] bg-neutral-300 shadow-xl shadow-gray-500 p-2 ml-4 mr-2 mb-4 mt-10 lg:text-2xl sm:text-sm font-bold leading-relaxed flex-column">
          <div className="flex justify-start pl-6">
            <h1 className="m-1">Q{activeQuestion + 1}: </h1>
            <div
              className="flex justify-between w-full m-1"
              id="question-container"
            >
              {questionArray[activeQuestion].question}
            </div>
          </div>

          <div className="flex-column w-full mt-10">
            <div className="flex justify-center">
              <div
                className={` border-solid border-2 flex items-center justify-center bg-gray-200 font-bold text-2xl border-black w-[450px] h-14 rounded-lg m-4 cursor-pointer hover:bg-slate-950 hover:text-white ${
                  selectedAnswer === 0
                    ? "bg-slate-950 text-white"
                    : "bg-gray-200"
                }`}
                onClick={() => {
                  setSelectedAnswer(0);
                  answerSelected(0);
                }}
              >
                {questionArray[activeQuestion].options[0]}
              </div>
              <div
                className={` border-solid border-2  flex items-center justify-center bg-gray-200 font-bold text-2xl border-black w-[450px] h-14 rounded-lg m-4 cursor-pointer hover:bg-slate-950 hover:text-white ${
                  selectedAnswer === 1
                    ? "bg-slate-950 text-white"
                    : "bg-gray-200"
                }`}
                onClick={() => {
                  setSelectedAnswer(1);
                  answerSelected(1);
                }}
              >
                {questionArray[activeQuestion].options[1]}
              </div>
            </div>
            <div className="flex justify-center">
              <div
                className={`border-solid border-2 flex items-center justify-center bg-gray-200 font-bold text-2xl border-black w-[450px] h-14 rounded-lg m-4 cursor-pointer hover:bg-slate-950 hover:text-white ${
                  selectedAnswer === 2
                    ? "bg-slate-950 text-white"
                    : "bg-gray-200"
                }`}
                onClick={() => {
                  setSelectedAnswer(2);
                  answerSelected(2);
                }}
              >
                {questionArray[activeQuestion].options[2]}
              </div>
              <div
                className={`border-solid border-2 flex items-center justify-center bg-gray-200 font-bold text-2xl border-black w-[450px] h-14 rounded-lg m-4 cursor-pointer hover:bg-slate-950 hover:text-white ${
                  selectedAnswer === 3
                    ? "bg-slate-950 text-white"
                    : "bg-gray-200"
                }`}
                onClick={() => {
                  setSelectedAnswer(3);
                  answerSelected(3);
                }}
              >
                {questionArray[activeQuestion].options[3]}
              </div>
            </div>
          </div>
        </div>
        <div className=" bg-neutral-300 ml-4 mr-2 h-[18vh] m-2 flex items-center justify-evenly shadow-xl shadow-gray-500">
        <button
              type="button"
              className={`m-2 inline-block rounded bg-primary w-[8vw] pb-2 pt-2.5 lg:text-xl sm:text-sm font-bold uppercase leading-normal text-white transition duration-150 ease-in-out hover:bg-primary-800 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] shadow-xl shadow-black ${activeQuestion === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              onClick={() => {
                if (activeQuestion > 0) {
                  setSelectedAnswer(null);
                  makeVisited(activeQuestion - 1);
                  setActiveQuestion(activeQuestion - 1);
                }
              }}
              disabled={activeQuestion === 0}
            >
              Previous
            </button>
          <button
            type="button"
            className=" m-2 inline-block rounded font-bold bg-success w-[8vw] pb-2 pt-2.5 lg:text-xl sm:text-sm uppercase leading-normal text-white transition duration-150 ease-in-out hover:bg-green-800 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] shadow-xl shadow-black"
            onClick={saveAnswer}
          >
            Save
          </button>
          <button
            type="button"
            className=" m-2 inline-block rounded bg-primary w-[8vw] pb-2 pt-2.5 lg:text-xl sm:text-sm  font-bold uppercase leading-normal text-white transition duration-150 ease-in-out hover:bg-primary-800 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] shadow-xl shadow-black"
            onClick={() => {
              setSelectedAnswer(null);
              makeVisited(activeQuestion + 1 === questionArray.length ? 0 : activeQuestion+1);
              setActiveQuestion(activeQuestion + 1 === questionArray.length ? 0 : activeQuestion+1);
            }}
          >
            Next
          </button>
          <button
            type="button"
            className=" m-2 inline-block rounded bg-danger w-[8vw] pb-2 pt-2.5 lg:text-xl sm:text-sm  font-bold uppercase leading-normal text-white transition duration-150 ease-in-out hover:bg-red-800 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] shadow-xl shadow-black"
            onClick={() => {
              clearAnswer(activeQuestion);
            }}
          >
            Clear
          </button>
        </div>
      </div>
      <div className=" shadow-xl shadow-gray-500 xs:w-[30vw] sm:w-[30vw] lg:w-[15vw] h-[75vh] bg-neutral-300 p-2 mr-4 ml-2 mb-4 mt-10 text-base font-light leading-relaxed flex-column ">
        <div className="flex-column mt-8 ">
          <div className="flex-column justify-center">
            <div className="m-4 p-2 lg:h-[4vh] lg:w-[12vw] bg-neutral-100 flex items-center rounded-xl ">
              <div className="h-[20px] w-[20px] bg-yellow-400 rounded-full m-2"></div>
              <p className="lg:text-xl sm:text-xs xs:text-xs">Visited</p>
            </div>
            <div className="m-4 p-2 lg:h-[4vh] lg:w-[12vw] bg-neutral-100 flex items-center rounded-xl ">
              <div className=" h-[20px] w-[20px] bg-green-800 rounded-full m-2"></div>
              <p className="lg:text-xl sm:text-xs xs:text-xs">Answered</p>
            </div>
            {/* <div className="m-4 p-2 lg:h-[6vh] lg:w-[13vw] bg-neutral-100 flex items-center rounded-xl ">
              <div className=" h-[40px] w-[40px] bg-red-800 rounded-full m-2"></div>
              <p className="lg:text-xl sm:text-xs xs:text-xs">Not-Answered</p>
            </div> */}
            <div className="m-4 p-2 lg:h-[4vh] lg:w-[12vw] bg-neutral-100 flex items-center rounded-xl mb">
              <div className=" h-[20px] w-[20px] bg-gray-400 rounded-full m-2"></div>
              <p className="lg:text-xl sm:text-xs xs:text-xs">Not-Visited</p>
            </div>
          </div>
        </div>
        <div className="flex-column">
          <div className="flex-column mt-12">
            {renderRow(0)}
            {renderRow(5)}
            {renderRow(10)}
            {renderRow(15)}
          </div>
        </div>
        <button
          className="m-3 inline-block rounded font-bold bg-purple-500 w-[8vw] pb-2 pt-2.5 lg:text-xl sm:text-sm uppercase leading-normal text-white transition duration-150 ease-in-out hover:bg-purple-800 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-purple-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] shadow-xl shadow-black"
          onClick={submitResponses}
        >
          Submit
        </button>
      </div>
    </div>
  );
}

export default Question;